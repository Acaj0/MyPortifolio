<?php
/**
 * Title: Tags and date
 * Slug: vivre/post-terms-and-date
 * Inserter: no
 */

?>

<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:post-terms {"term":"category"} /-->
<!-- wp:post-date {"isLink":true,"style":{"typography":{"fontStyle":"italic","fontWeight":"400","fontSize":"14px"}}} /--></div>
<!-- /wp:group -->
